<?php return array (
  'live-table' => 'App\\Http\\Livewire\\LiveTable',
);