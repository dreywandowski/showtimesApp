

## Showtimes Application

#### Browse for movie listings at various cinemas across Lagos with the times.
#### About 3 movies and 3 cinemas have been added to their respective tables, while some sample movie listings against cinemas have also been created. 
#### Live link: https://adura-shop.000webhostapp.com/shop

#### Logged-in Users can make create new movie listings, view details, update and delete movie listings.




