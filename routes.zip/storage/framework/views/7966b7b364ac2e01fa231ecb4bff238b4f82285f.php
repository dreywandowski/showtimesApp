<?php $__env->startSection('content'); ?>

    <div>



            <?php if(Session::has('message')): ?>

            <p class="alert-warning" > <?php echo e(Session::get('message')); ?>

            <?php endif; ?>

        <div class="row">
            <div><a href="/cinemas/create_form" class="btn btn-sm btn-primary">
                                Create a new listing
                                </a>
<br><br>
</div>

            <?php if($data->count()): ?>
                <table class="table">
                    <thead>
                    <tr>
                       <th>
                          
                              &nbsp; &nbsp;   Movie
                            </a>
                        </th>
                       <th>
                        
                                Cinema
                            </a>
                        </th>
                        <th>
                            
                                Showtime
                            </a>
                        </th>
                    
                     <th>
                            View Details
                        </th>

                         <th>
                            Edit
                        </th>
                        <th>
                            Delete
                        </th>
                       
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> 
                              &nbsp; &nbsp;  <?php echo e($movie->movie); ?></td>
                            <td><?php echo e($movie->cinema); ?></td>
                            <td><?php echo e(date("F jS Y, g:i a", strtotime($movie->showtime))); ?></td>
                            <td>
                                <a href="/cinemas/show/<?php echo e($movie->id); ?>" class="btn btn-sm btn-primary">
                                View Details
                                </a>
                            </td>
        
                            <td>
                                <a href="/cinemas/update_form/<?php echo e($movie->id); ?>" class="btn btn-sm btn-primary">
                                    Edit
                                </a>
                            </td>
                               <td>
                              <a href="/cinemas/destroy/<?php echo e($movie->id); ?>" class="btn remove  btn-primary">
                              Delete</a>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-warning">
                    Your query returned zero results.
                </div>
            <?php endif; ?>
        </div>
</div>
<br><br>


<center>
   <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>

                                </div>
                            </center>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.cinemas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cinemas-app\resources\views/cinemas.blade.php ENDPATH**/ ?>