<?php $__env->startSection('content'); ?>

<?php if($data): ?>

<div class="bg-light py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12 mb-0"><a href="/shop">Home</a> <span class="mx-2 mb-0">/</span> <?php echo e($data['movie']); ?><strong class="text-black"></strong></div>
        </div><span class="mx-2 mb-0" id="ajaxRep" style="color:green"></span>
      </div>

      <ol>
        <li> Movie Name: <?php echo e($data['movie']); ?></li><br>
         <li> Cinema Showing: <?php echo e($data['cinema']); ?></li><br>
          <li> Time Showing: <?php echo e(date("F jS Y, g:i a", strtotime($data['showtime']))); ?></li><br>
          
      </ol>
    </div>  

<a href="/cinemas" class="btn btn-sm btn-primary">
                                Go Home
                                </a>
     
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.cinemas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cinemas-app\resources\views/cinemas/show.blade.php ENDPATH**/ ?>