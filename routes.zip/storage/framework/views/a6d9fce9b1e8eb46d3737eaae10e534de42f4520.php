<?php $__env->startSection('content'); ?>



    <div class="bg-light py-3">
        <div class="container">
            <div class="row">
                <div class="col-md-12 mb-0"><a href="/shop">Home</a> <span class="mx-2 mb-0">/</span> <strong class="text-black">My Orders</strong></div>
            </div>
        </div>
    </div>

    <div style="margin-left: 10%" class="site-section">
        <disv class="container">
            <div class="row mb-5" style="overflow-x:auto;">
                <!--<form class="col-md-12" method="post" style="overflow-x:auto;">-->
                <div class="site-blocks-table" style="overflow-x:auto;">
                    <?php if($order != null): ?> <caption style="color:black"><h3><center><u>My Orders</center></u></h3> </caption>
                    <table class="table table-bordered" style="overflow-x:auto;">

                        <thead>
                        <tr>
                            <th class="ID">ID</th>
                            <th class="Log Time">Log Time</th>
                            <th class="Items">Items</th>
                            <th class="Amount">Amount</th>
                            <th class="Payment Reference">Payment Reference</th>
                            <th class="Status">Status</th>
                            <th class="Channel">Channel</th>
                            <th class="type">Pay Type</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($item['id']); ?></td>
                                    <td><?php echo e(date('l jS \of F Y h:i:s A', strtotime($item['updated_at']))); ?></td>
                                    <td>
                                       <?php $__currentLoopData = $item['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e($items[0]['file']); ?>" alt="Image" style="height: 80px;
width: 80px;">
                                            <?php echo e($items[0]['name']); ?>, <?php echo e($items[0]['number']); ?> items @ NGN<?php echo e($items[0]['price']); ?><hr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>NGN <?php echo e($item['amount']); ?></td>
                                    <td><?php echo e($item['ref']); ?></td>
                                    <td><?php echo e($item['status']); ?></td>
                                    <td><?php echo e($item['channel']); ?></td>
                                    <td><?php echo e($item['pay_type']); ?></td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        </tbody>
                    </table>
                </div>
                <!-- </form>-->
            </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('shop-layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shopping-cart\resources\views/shopping-cart/orders.blade.php ENDPATH**/ ?>